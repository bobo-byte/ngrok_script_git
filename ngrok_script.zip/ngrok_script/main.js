const { exec } = require("child_process")
const install = require("./install.js");


const file_name = "path.bat";
const file_path  = `${__dirname}/${file_name}`;


const INSTALLED_MSG = "Ngrok already installed!";
const SUCCESS_MSG = "Ngrok installed and path added";
const LAUNCH_MSG = "Launching locahost using tunnel.";


const command = `start.bat`;

function main(){
	install
	.run()
	.then(() => { // installed variable exists
			// Add to path
			// This is for the bat file to add ngrok.exe to executable path.
			exec(command, function (error, stdout, stderr) {
				if(stdout) console.log(stdout);
				if(error) console.error(error);
			});
			console.log(LAUNCH_MSG);		
	})
	.catch(error => console.error(error));
}


main();
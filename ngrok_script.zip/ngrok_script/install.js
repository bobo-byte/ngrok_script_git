const fs = require("fs");
const https = require("https");
const AdmZip = require("adm-zip");
const path = require("path");

const FEEDBACK = {
	DOWNLOAD: {
		STATUS: {
		   START: "Downloading ngrok..",
		   FINISH: "Finished downloading.",
		}, 
		ERROR: {
			FAIL: "Download failed: ",
			
		}, 
	}, 
	ZIP: {
		STATUS: {
		  START: "File extraction: Starting!..",
		  EXIST: "File extraction: File exists!",
		  FINISH: "File extraction: Success! ",
		  REMOVE_START: "Removing ngrok.zip file..",
		  REMOVE_FINISH: "Removed ngrok.zip file: Success!"
		},
		ERROR: {
		 NOT_EXIST: "File does not exist!",
	     EXTRACT: "Zip extraction failed!: ",
		 REMOVE: "Failed to remove zip: ",
		}
	}
}

const PATHS = {
	zip_file: `${__dirname}/ngrok.zip`,
}

/*
Function checks if ngrok.exe exists.
*/
function check() {
   const exe_file = `${__dirname}/ngrok.exe`;	
   return new Promise((resolve, reject) => {
	   fs.access(exe_file, fs.F_OK, (err) => {
			if(err) return reject(get_file());	// zip file exists?		
			resolve();
	   });
   });	
}


/*
Function to download ngrok.exe if it does not exist
*/
function download(){
	const URL = "https://bin.equinox.io/c/bNyj1mQVY4c/ngrok-v3-stable-windows-amd64.zip";
	
	const { DOWNLOAD } = FEEDBACK;
	
	const { STATUS, ERROR } = DOWNLOAD;
	
	return new Promise((resolve, reject) => {
		 console.log(STATUS.START);
		 https.get(URL, res => {
			 
			const file = fs.createWriteStream(PATHS.zip_file); 
			
			res.pipe(file);
			
			file.on("finish", () => {
				file.close();
				console.log(STATUS.FINISH);
				resolve();
			})
			.on("error", (error) => {
				  reject(ERROR.FAIL + error.message);
			});
		 })
	});
}


/*
Function to unzip downloaded file from ngrok.com/download
*/
function unzip(){	
	const { ZIP } = FEEDBACK;	
	const { STATUS, ERROR } = ZIP;
		
	return new Promise((resolve, reject) => {
		console.log(STATUS.START);	
			try {
				const zip = new AdmZip(PATHS.zip_file);
				zip.extractAllTo(__dirname);
				
				console.log(STATUS.FINISH);
				resolve();
			} catch (error) {
				reject(ERROR.EXTRACT + error.message);
			}	
	});
}

function delete_zip(){	
	const { ZIP } = FEEDBACK;
	const { STATUS, ERROR } = ZIP;
	
	fs.unlink(PATHS.zip_file, (error) => {
		console.log(STATUS.REMOVE_START);

		if(error) console.error(ERROR.REMOVE + error);
		else console.log(STATUS.REMOVE_FINISH);
	});
}

function get_file(){
	const EXT = ".zip";
	
	const files = fs.readdirSync(__dirname).filter(file => {
		return path.extname(file).toLowerCase() == EXT;
	});
	
	return files[0] || ""; // should be only one zip file.
}


module.exports = {
	run: () => {
    return new Promise((resolve, reject) => {
		
		function success_unzip() {
			delete_zip();
			resolve(true);
		}
		
			check()
			.then(() => {
				resolve(false)
				}) // already exist.
			.catch((zip_file) => { 
				// zip file does not exist.
				if (zip_file == "") {  
					// download zip file.
					download()
					.then(() => {
						unzip()
							.then(() => {
								success_unzip();
							})
							.catch(error => reject(error));
					}).catch(error => reject(error));
					
				} else {
					// zip file already exists.
					unzip()
						.then(() => {
							success_unzip();
						})
						.catch(error => reject(error)); 
				}
			});
		});
	}
} 